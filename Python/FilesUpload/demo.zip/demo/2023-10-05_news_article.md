# Stock Advisory: Healthcare and Energy Themes

## Energy Stocks

### Exxon Mobil Corp (XOM)
- **Pros:**
  - Robust cash flow
  - Attractive dividend yield
  - Well-positioned to benefit from global energy demand
  - 7.3% undervalued offering potential for price appreciation
- **Cons:**
  - Exposure to volatile oil prices
  - Increasing regulatory and environmental pressures

### Schlumberger Ltd (SLB)
- **Pros:**
  - Leading oilfield services company
  - Provides essential services and technology for global exploration and drilling
  - Strategic play within the energy sector
- **Cons:**
  - Dependence on oil and gas industry cycles
  - Intense competition within the sector

The picked stocks are recommended based on their strategic positioning within the energy theme and potential market performance.